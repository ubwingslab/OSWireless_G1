import numpy as np
lkcap_link_2 = 1
pnl_coefficient = np.array([0])
