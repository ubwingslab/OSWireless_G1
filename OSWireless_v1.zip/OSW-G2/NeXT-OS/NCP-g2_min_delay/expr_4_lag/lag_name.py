value = 'expr_4_lag'
alg_name = '../NeXT-OS/NCP-g2_min_delay'