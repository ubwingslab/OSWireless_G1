value = '__phy_node_0'
hid = 'node_0'
algo_name = '../NeXT-OS/NCP-g2_min_delay'