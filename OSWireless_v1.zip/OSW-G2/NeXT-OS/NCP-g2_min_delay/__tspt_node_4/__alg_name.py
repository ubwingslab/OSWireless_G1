value = '__tspt_node_4'
hid = 'node_4'
algo_name = '../NeXT-OS/NCP-g2_min_delay'