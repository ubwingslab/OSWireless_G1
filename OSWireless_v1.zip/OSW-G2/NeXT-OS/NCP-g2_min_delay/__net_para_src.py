import numpy as np
theta_0_0 = 1
lkcap_link_0 = 1
ssrate_session_0 = 1
theta_1_0 = 1
lkcap_link_1 = 1
theta_2_0 = 1
lkcap_link_2 = 1
theta_3_1 = 1
lkcap_link_3 = 1
ssrate_session_1 = 1
theta_4_1 = 1
lkcap_link_4 = 1
theta_5_1 = 1
lkcap_link_5 = 1
