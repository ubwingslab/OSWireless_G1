import numpy as np
lkcap_link_4 = 1
pnl_coefficient = np.array([0])
