import numpy as np
lkcap_link_1 = 1
pnl_coefficient = np.array([0])
