value = 'expr_2_lag'
alg_name = '../NeXT-OS/NCP-g2_min_delay'