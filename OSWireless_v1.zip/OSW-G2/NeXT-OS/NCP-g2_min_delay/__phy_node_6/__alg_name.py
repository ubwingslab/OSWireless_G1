value = '__phy_node_6'
hid = 'node_6'
algo_name = '../NeXT-OS/NCP-g2_min_delay'