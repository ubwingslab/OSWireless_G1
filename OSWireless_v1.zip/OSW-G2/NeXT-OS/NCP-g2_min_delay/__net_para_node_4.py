import numpy as np
theta_3_1 = 1
theta_4_1 = 1
theta_5_1 = 1
ssrate_session_1 = 1
pnl_coefficient = np.array([0])
lkcap_link_3 = 1
