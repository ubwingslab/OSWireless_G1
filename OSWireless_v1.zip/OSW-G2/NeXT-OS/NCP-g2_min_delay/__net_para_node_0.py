import numpy as np
theta_0_0 = 1
theta_1_0 = 1
theta_2_0 = 1
ssrate_session_0 = 1
pnl_coefficient = np.array([0])
lkcap_link_0 = 1
