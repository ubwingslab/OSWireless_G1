import numpy as np
lkpwr_link_4 = 1
lkitf_link_4 = 1
coord_x_link_4 = 1
fx_crd_x_link_4 = 1
coord_y_link_4 = 1
fx_crd_y_link_4 = 1
pnl_coefficient = np.array([0, 0])
ssrate_session_1 = 1
lkcap_link_4 = 1
