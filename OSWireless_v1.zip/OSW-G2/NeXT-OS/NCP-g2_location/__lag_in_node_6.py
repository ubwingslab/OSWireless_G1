expr_6_lag = 0  # Initialized to zero, updated at network run time
