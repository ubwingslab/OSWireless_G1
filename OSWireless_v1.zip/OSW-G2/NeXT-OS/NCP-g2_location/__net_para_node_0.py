import numpy as np
ssrate_session_0 = 1
pnl_coefficient = np.array([0])
lkpwr_link_0 = 1
lkitf_link_0 = 1
coord_x_link_0 = 1
fx_crd_x_link_0 = 1
coord_y_link_0 = 1
fx_crd_y_link_0 = 1
pnl_coefficient = np.array([0, 0])
lkcap_link_0 = 1
