expr_1_lag = 0  # Initialized to zero, updated at network run time
expr_2_lag = 0  # Initialized to zero, updated at network run time
expr_3_lag = 0  # Initialized to zero, updated at network run time
