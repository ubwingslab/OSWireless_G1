# Current value, initialized to 1, updated at network run time. 
cur_val = 1

# Step size, initialized to 0.1
lag_step = 0.1