value = 'expr_1_lag'
alg_name = '../NeXT-OS/NCP-g2_location'