value = '__phy_node_5'
hid = 'node_5'
algo_name = '../NeXT-OS/NCP-g2_location'