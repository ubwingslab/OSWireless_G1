value = 'expr_3_lag'
alg_name = '../NeXT-OS/NCP-g2_location'