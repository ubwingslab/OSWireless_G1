value = '__phy_node_4'
hid = 'node_4'
algo_name = '../NeXT-OS/NCP-g2_location'