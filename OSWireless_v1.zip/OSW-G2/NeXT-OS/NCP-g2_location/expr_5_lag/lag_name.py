value = 'expr_5_lag'
alg_name = '../NeXT-OS/NCP-g2_location'