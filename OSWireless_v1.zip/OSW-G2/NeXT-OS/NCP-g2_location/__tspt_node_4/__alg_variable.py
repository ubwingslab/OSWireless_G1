value = 'ssrate_session_1'
key = 'ssrate'
