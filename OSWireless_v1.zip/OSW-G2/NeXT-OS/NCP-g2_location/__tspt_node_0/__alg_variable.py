value = 'ssrate_session_0'
key = 'ssrate'
