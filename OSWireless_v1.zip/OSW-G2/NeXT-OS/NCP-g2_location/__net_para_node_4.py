import numpy as np
ssrate_session_1 = 1
pnl_coefficient = np.array([0])
lkpwr_link_3 = 1
lkitf_link_3 = 1
coord_x_link_3 = 1
fx_crd_x_link_3 = 1
coord_y_link_3 = 1
fx_crd_y_link_3 = 1
pnl_coefficient = np.array([0, 0])
lkcap_link_3 = 1
