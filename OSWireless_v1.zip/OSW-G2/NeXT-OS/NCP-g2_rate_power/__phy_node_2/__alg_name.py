value = '__phy_node_2'
hid = 'node_2'
algo_name = '../NeXT-OS/NCP-g2_rate_power'