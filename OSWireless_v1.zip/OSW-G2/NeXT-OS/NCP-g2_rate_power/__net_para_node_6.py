import numpy as np
lkgain_link_5 = 1
lkpwr_link_5 = 1
lkitf_link_5 = 1
pnl_coefficient = np.array([0])
ssrate_session_1 = 1
lkcap_link_5 = 1
