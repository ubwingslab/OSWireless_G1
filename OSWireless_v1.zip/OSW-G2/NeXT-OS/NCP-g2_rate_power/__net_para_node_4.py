import numpy as np
ssrate_session_1 = 1
pnl_coefficient = np.array([0])
lkgain_link_3 = 1
lkpwr_link_3 = 1
lkitf_link_3 = 1
lkcap_link_3 = 1
