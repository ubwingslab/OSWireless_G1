import numpy as np
ssrate_session_0 = 1
pnl_coefficient = np.array([0])
lkgain_link_0 = 1
lkpwr_link_0 = 1
lkitf_link_0 = 1
lkcap_link_0 = 1
