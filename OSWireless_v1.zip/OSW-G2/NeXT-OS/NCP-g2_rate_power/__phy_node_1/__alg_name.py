value = '__phy_node_1'
hid = 'node_1'
algo_name = '../NeXT-OS/NCP-g2_rate_power'