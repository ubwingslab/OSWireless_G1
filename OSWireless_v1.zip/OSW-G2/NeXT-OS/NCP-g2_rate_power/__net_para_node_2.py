import numpy as np
lkgain_link_2 = 1
lkpwr_link_2 = 1
lkitf_link_2 = 1
pnl_coefficient = np.array([0])
ssrate_session_0 = 1
lkcap_link_2 = 1
