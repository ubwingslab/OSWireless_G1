import net_name_g2

def expr_cnst(nt):
    expr = {'expr_xpd': '', 'expr_ori': ''}

    for link in nt.get_list('microwave_link'):                                                   # Loop over the links in link list
        #print(link)
        lkobj = nt.get_netelmt_g2(link)                                      # Get the link object
        lkcap_expr = nt.get_expr_g2(link, net_name_g2.lkcap)                 # Get the expression for link capacity
        print(link, lkcap_expr)