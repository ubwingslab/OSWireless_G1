#################################
#######Interference Details######
#################################

itf_lk_nd = {}

itf_lk_nd['link_1_2'] = [5, 2]
itf_lk_nd['link_2_3'] = [7, 3]
itf_lk_nd['link_3_4'] = [8, 4]

itf_lk_nd['link_5_6'] = [1, 6]
itf_lk_nd['link_6_7'] = [2, 7]
itf_lk_nd['link_7_8'] = [3, 8]
itf_lk_nd['link_5_7'] = [1, 7]
itf_lk_nd['link_7_8'] = [2, 8]
itf_lk_nd['link_8_6'] = [3, 6]

#################################
mul_var_flag = False

expansion_flag = True