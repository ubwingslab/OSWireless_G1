# Mapping from the generated algorithms to nodes
node_0= []
node_0.append('__tspt_node_0')
node_4= []
node_4.append('__tspt_node_4')
node_0.append('__phy_node_0')
node_1= []
node_1.append('__phy_node_1')
node_2= []
node_2.append('__phy_node_2')
node_4.append('__phy_node_4')
node_5= []
node_5.append('__phy_node_5')
node_6= []
node_6.append('__phy_node_6')
