#######################################################
### Automatically Generated File
### Mapping nodes to corresponding session and link
#######################################################
node_0 = {}
node_0['link'] = 'link_0'
node_0['session'] = ['session_0']
node_1 = {}
node_1['link'] = 'link_1'
node_1['session'] = ['session_0']
node_2 = {}
node_2['link'] = 'link_2'
node_2['session'] = ['session_0']
node_4 = {}
node_4['link'] = 'link_3'
node_4['session'] = ['session_1']
node_5 = {}
node_5['link'] = 'link_4'
node_5['session'] = ['session_1']
node_6 = {}
node_6['link'] = 'link_5'
node_6['session'] = ['session_1']
