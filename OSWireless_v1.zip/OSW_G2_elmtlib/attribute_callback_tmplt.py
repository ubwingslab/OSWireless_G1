
def callback(elmtobj, ntwk, ncp):
    '''
    This callback function will be executed when this parameter is detected in an expression of the 
    network control problem (utility or constraint).
    
    elmtobj: object of the network element for which the callback function is called
    ntwk: the network object
    ncp: object of the network control problem
    
    Return: A new expression that will be added to the set of expressions of the network control problem (ncp)
    '''        
    expr = ''
    
    ###############################################
    # your code for internal expression definition
    # ...
    ###############################################
    
    return expr
    
