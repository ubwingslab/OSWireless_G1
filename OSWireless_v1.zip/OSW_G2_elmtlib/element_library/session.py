#######################################################
# Code Date: 2021-07-15 10:59:48.808562

# Author: Zhangyu Guan, Sabarish Krishna Moorthy
# Automatically generated session class
#######################################################

import net_func_g2

class session(net_func_g2.netelmt_g2):
    '''
    session Class
    '''
    def __init__(self, info):    
        # from base network element
        net_func_g2.netelmt_g2.__init__(self, info)
        
        self.type = 'session'
        
        self.update_flag = False
        
        self.node_set = []
                    
            
    def update_info(self):
        src_obj = self.ntwk.get_netelmt_g2(self.link_set[0])
        dst_obj = self.ntwk.get_netelmt_g2(self.link_set[-1])
        self.src = src_obj.tsmt_nd
        self.dst = dst_obj.rcvr_nd
        

        
                
                    
        
        
        
        