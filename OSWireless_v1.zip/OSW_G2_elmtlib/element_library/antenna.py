#######################################################
# Code Date: 2021-07-15 10:59:53.530776

# Author: Zhangyu Guan, Sabarish Krishna Moorthy
# Automatically generated antenna class
#######################################################

import net_func_g2

class antenna(net_func_g2.netelmt_g2):
    '''
    antenna Class
    '''
    def __init__(self, info):    
        # from base network element
        net_func_g2.netelmt_g2.__init__(self, info)
        
        self.type = 'antenna'