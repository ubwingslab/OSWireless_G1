#######################################################
# Code Date: 2021-07-15 10:59:38.713741

# Author: Zhangyu Guan, Sabarish Krishna Moorthy
# mmwave_mimo_node class
#######################################################

import net_func_g2, net_name_g2
import mmwave_directional_antenna
import mmwave_node

from net_ntwk_g2 import *

class mmwave_mimo_node(mmwave_node.mmwave_node):
    '''
    mmwave_mimo_node Class
    '''
    def __init__(self, info):    
        # from base network element
        mmwave_node.mmwave_node.__init__(self, info)
        num_antennas = info['addi_info']['num_ant']
        self.connect(net_name_g2.antenna, num_antennas)
        
        
        
        
        
        
        