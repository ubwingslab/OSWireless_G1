#######################################################
# Code Date: 2021-07-15 10:59:38.713741

# Author: Zhangyu Guan, Sabarish Krishna Moorthy
# Agent class
#######################################################

import net_func_g2, net_name_g2

from net_ntwk_g2 import *

class queue(net_func_g2.netelmt_g2):
    '''
    Queue Class
    '''
    def __init__(self, info):    
        # from base network element
        net_func_g2.netelmt_g2.__init__(self, info)
        
        self.type = 'queue'