#######################################################
# Code Date: 2021-07-15 10:59:43.401499

# Author: Zhangyu Guan, Sabarish Krishna Moorthy
# Automatically generated microwave_link class
#######################################################

import net_func_g2
import link

class microwave_link(link.link):
    '''
    microwave_link Class
    '''
    def __init__(self, info):    
        # from base network element
        link.link.__init__(self, info)
        
        self.oper_freq = 'micro'
