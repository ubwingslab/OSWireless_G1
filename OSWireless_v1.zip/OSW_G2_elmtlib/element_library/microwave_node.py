#######################################################
# Code Date: 2021-07-15 10:59:38.713741

# Author: Zhangyu Guan, Sabarish Krishna Moorthy
# Automatically generated node class
#######################################################

import net_func_g2, net_name_g2
import node

class microwave_node(node.node):
    '''
    node Class
    '''
    def __init__(self, info):    
        # from base network element
        node.node.__init__(self, info)
