#######################################################
# Code Date: 2021-07-15 10:59:43.401499

# Author: Zhangyu Guan, Sabarish Krishna Moorthy
# Automatically generated task class
#######################################################

import net_func_g2

class task(net_func_g2.netelmt_g2):
    '''
    link Class
    '''
    def __init__(self, info):    
        # from base network element
        net_func_g2.netelmt_g2.__init__(self, info)
        
        self.type = 'task'
        self.layer = 'env'
        self.task_alloc_limit = 1
        self.hid = 'name'
        self.update_flag = False
              