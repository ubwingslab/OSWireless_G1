#######################################################
# Code Date: 2021-07-15 10:59:53.530776

# Author: Zhangyu Guan, Sabarish Krishna Moorthy
# Automatically generated antenna class
#######################################################

import net_func_g2
import antenna

class directional_antenna(antenna.antenna):
    '''
    antenna Class
    '''
    def __init__(self, info):    
        # from base network element
        antenna.antenna.__init__(self, info)