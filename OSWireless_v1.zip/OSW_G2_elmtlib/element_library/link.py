#######################################################
# Code Date: 2021-07-15 10:59:43.401499

# Author: Zhangyu Guan, Sabarish Krishna Moorthy
# Automatically generated link class
#######################################################

import net_func_g2

class link(net_func_g2.netelmt_g2):
    '''
    link Class
    '''
    def __init__(self, info):    
        # from base network element
        net_func_g2.netelmt_g2.__init__(self, info)
        
        self.type = 'link'
        self.oper_freq = 'micro'
        self.update_flag = False
                    
            
    def update_info(self):
        self.tsmt_nd = self.node_set[0]
        self.rcvr_nd = self.node_set[1]
        self.hid = self.tsmt_nd