#######################################################
# Code Date: 2021-07-15 10:59:38.713741

# Author: Zhangyu Guan, Sabarish Krishna Moorthy
# Agent class
#######################################################

import net_func_g2, net_name_g2
import antenna
import node

from net_ntwk_g2 import *

class agent(node.node):
    '''
    Agent Class
    '''
    def __init__(self, info):    
        # from base network element
        node.node.__init__(self, info)
        self.max_num_of_tasks = 2
        self.layer = 'env'
        self.bundle_vector = None
        self.path_vector = None
        self.winning_agent_vector = None
        self.winning_bid_vector = None
        self.timestamp_vector = None
        self.hid = 'name'
        
    def update_info(self):
        self.hid = self.task_set
        
    def connect(self, element_name, num_elmnt):
        '''
        Create num_elmnt antennas and connect it to the mimo node
        '''       
        new_elmnts_list = self.ntwk.attach(element_name, num_elmnt)
        self.ntwk.connect(self.name, new_elmnts_list)
        
        
        
        
        
        
        