#######################################################
# Code Date: 2021-07-15 10:59:38.713741

# Author: Zhangyu Guan, Sabarish Krishna Moorthy
# Automatically generated node class
#######################################################

import net_func_g2, net_name_g2

class node(net_func_g2.netelmt_g2):
    '''
    node Class
    '''
    def __init__(self, info):    
        # from base network element
        net_func_g2.netelmt_g2.__init__(self, info)
        self.type = 'node'
        num_antennas = 1
        self.connect(net_name_g2.antenna, num_antennas)
        
    def connect(self, element_name, num_elmnt):
        '''
        Create num_elmnt antennas and connect it to the mimo node
        '''
        new_elmnts_list = self.ntwk.attach(element_name, num_elmnt)
        self.ntwk.connect(self.name, new_elmnts_list)
        