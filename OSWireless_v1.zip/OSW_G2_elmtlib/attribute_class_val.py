class_name = "___fx_crd_z___"
module_name = "net_func_g2"
base_class_name = "netelmt_g2"
