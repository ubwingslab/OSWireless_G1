#######################################################
#[[[cog
#   import cog, datetime
#   cog.outl("# Code Date: %s" % datetime.datetime.now())
#]]]
#[[[end]]]

# Author: Zhangyu Guan, Sabarish Krishna Moorthy
#[[[cog
#   import cog
#   import g2_attribute_class_val as acv
#   cog.outl("# Automatically generated %s class" %(acv.class_name))
#]]]
#[[[end]]]
#######################################################

#[[[cog
#   import cog
#   import g2_attribute_class_val as acv
#   cog.outl("import ___%s___\n"%(acv.module_name))
#   cog.outl("class %s(___%s___.___%s___):" %(acv.class_name, acv.module_name, acv.base_class_name))
#   cog.outl("    '''")
#   cog.outl("    %s Class" %(acv.class_name))
#   cog.outl("    '''")
#]]]
#[[[end]]]
    '''
    class of network parameters and variables
    '''
    def __init__(self, info):    
        # from base network element
        
        #[[[cog
        #   import cog
        #   import g2_attribute_class_val as acv
        #   cog.outl("___%s___.___%s___.__init__(self, info)" %(acv.module_name, acv.base_class_name))
        #]]]
        #[[[end]]]
  
        