#######################################################
#[[[cog
#   import cog, datetime
#   cog.outl("# Code Date: %s" % datetime.datetime.now())
#]]]
#[[[end]]]

# Author: Zhangyu Guan, Sabarish Krishna Moorthy
#[[[cog
#   import cog
#   import elmt_tmplt_val as etv
#   cog.outl("# Automatically generated %s class" %(etv.class_name))
#]]]
#[[[end]]]
#######################################################

#[[[cog
#   import cog
#   import elmt_tmplt_val as etv
#   cog.outl("import net_func_g2\n")
#   cog.outl("class %s(net_func_g2.netelmt_g2):" %(etv.class_name))
#   cog.outl("    '''")
#   cog.outl("    %s Class" %(etv.class_name))
#   cog.outl("    '''")
#]]]
#[[[end]]]
    def __init__(self, info):    
        # from base network element
        net_func_g2.netelmt_g2.__init__(self, info)
        
        #[[[cog 
        #   import cog
        #   import elmt_tmplt_val as etv
        #   cog.outl("self.type = '%s'" %(etv.class_name))
        #]]]
        #[[[end]]]
        