#######################################################
# Code Date: 2022-01-25 11:46:25.349942

# Author: Zhangyu Guan, Sabarish Krishna Moorthy
# Automatically generated ___lksinr___ class
#######################################################

import net_func_g2

class ___lksinr___(net_func_g2.netelmt_g2):
    '''
    ___lksinr___ Class
    '''
    '''
    class of network parameters and variables
    '''
    def __init__(self, info):    
        # from base network element
        
        net_func_g2.netelmt_g2.__init__(self, info)

        # properties of parameter
        self.expr_hldr  =  None        # Symbolic expression of the element; There should be an expression management module
        self.expr_hldr_xtnl = None                          # external expression
                
        # protocol code: the code will be used to identify which function should be called to express a variable
        self.ptcl_code  = None

        # Lower and upper bounds of the parameter. APIs should be provided to set these bounds, hard coded for now.
        self.lwr_bnd = 'default'
        self.upr_bnd = 'default'   

        # if callback has been executed?
        self.callback_executed = False
    
        # self.para_type  =  info['addi_info']['para_type']   # parameter type
        
        for elmt in info['addi_info'].keys():
            if not hasattr(self, elmt):
                setattr(self, elmt, info['addi_info'][elmt])        
        