#######################################################
# Code Date: 2022-01-25 11:43:42.645108

# Author: Zhangyu Guan, Sabarish Krishna Moorthy
# Automatically generated ___ssrate___ class
#######################################################

import ___net_func_g2___

class ___ssrate___(___net_func_g2___.___netelmt_g2___):
    '''
    ___ssrate___ Class
    '''
    '''
    class of network parameters and variables
    '''
    def __init__(self, info):    
        # from base network element
        
        ___net_func_g2___.___netelmt_g2___.__init__(self, info)
  
        