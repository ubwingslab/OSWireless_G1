#######################################################
# Code Date: 2022-01-25 11:43:34.169803

# Author: Zhangyu Guan, Sabarish Krishna Moorthy
# Automatically generated ___mmwave_lkcap___ class
#######################################################

import ___lkcap___

class ___mmwave_lkcap___(___lkcap___.___lkcap___):
    '''
    ___mmwave_lkcap___ Class
    '''
    '''
    class of network parameters and variables
    '''
    def __init__(self, info):    
        # from base network element
        
        ___lkcap___.___lkcap___.__init__(self, info)
  
        