#######################################################
# Code Date: 2022-01-25 11:43:36.597270

# Author: Zhangyu Guan, Sabarish Krishna Moorthy
# Automatically generated ___lkdist___ class
#######################################################

import ___net_func_g2___

class ___lkdist___(___net_func_g2___.___netelmt_g2___):
    '''
    ___lkdist___ Class
    '''
    '''
    class of network parameters and variables
    '''
    def __init__(self, info):    
        # from base network element
        
        ___net_func_g2___.___netelmt_g2___.__init__(self, info)
  
        