#######################################################
# Code Date: 2022-01-25 11:43:40.225292

# Author: Zhangyu Guan, Sabarish Krishna Moorthy
# Automatically generated ___lkinrate___ class
#######################################################

import ___net_func_g2___

class ___lkinrate___(___net_func_g2___.___netelmt_g2___):
    '''
    ___lkinrate___ Class
    '''
    '''
    class of network parameters and variables
    '''
    def __init__(self, info):    
        # from base network element
        
        ___net_func_g2___.___netelmt_g2___.__init__(self, info)
  
        