'''
Author: Sabarish Krishna Moorthy, Zhangyu Guan
'''

#Attribute Generator
import sys, os, time, inspect
current_dir = os.path.dirname(os.path.abspath(inspect.getfile(inspect.currentframe())))
parent_dir = os.path.dirname(current_dir)
sys.path.insert(0, parent_dir+'\\OSW-G2\\NeXT-OS\\wos-network') 
import net_name_g2 as nng
import subprocess

########################################################################
def dic_2_str(dict):
    '''
    convert a dictionary to a string
    '''
    # get the list of keys of the dictionary
    list_key = dict.keys()    
        
    # initialize the overall string to be empty 
    overall_str = ''       
    
    # add each key and its value to a string
    for this_key in list_key:
        # construc the current part of string
        cur_str = "'" + this_key + "': '" + dict[this_key] + "'," 
    
        # add current string to the overall string
        overall_str = overall_str + cur_str
        
    return overall_str[:-1]    # no need to return the last comma
########################################################################

# Information of the network parameter to be defined

# Added a class with specific attributes

def add_attribute(info):
    # for session parameters
    para_info = {}
    para_info['class_name'] = info['class_name']             #net_name.ssrate}      # name of the class to be generated
    para_info['parent_class'] = info['parent_cls']         #net_name.ss_prnt_cls  # parent class
    para_info['para_type'] = info['para_type']               #net_name.leaf_para    # is this parameter a leaf parameter?
    para_info['layer'] = info['layer']                       #net_name.tspt         # protocol layer of this parameter
    para_info['hid'] = info['hid']                           #net_name.src          # this parameter is controlled by source node
    #para_info['sub_type'] = info['stype']                 #net_name.rate         # general category of this parameter
    return para_info

def do_cogapp(para_info):
    out_file = './'+'attribute_library/'+'___' + para_info['class_name'] + '___' + '.py'  # this is output file name
    #################################################################
    # Generate the class file
    os.system('python -m cogapp -d -o ' + out_file + ' attribute_tmplt.py ')
    #################################################################
    # Generate callback file
    out_file = './'+'attribute_library/'+'___' + para_info['class_name'] + '__callback' + '.py'  # this is output file name
    os.system('python -m cogapp -d -o ' + out_file + ' attribute_callback_tmplt.py ')
    
def do_file_ops(para_info): #, addi_info):
    # convert the dictionary to a string
    para_info_val_in_str = dic_2_str(para_info)
    #Function encapsulating all of the housekeeping file operations for the defined attribute
    #################################################################
    # write information into a file for temporary use
    with open ('./'+"attribute_tmplt_val.py",'w+') as f1:
        f1.write("addi_info = {" + para_info_val_in_str + "}")
        f1.close()
    with open ('./'+"attribute_class_val.py",'w+') as f2:
        f2.write("class_name = \"___%s___\"\n"%para_info['class_name'])
        f2.close()
    do_cogapp(para_info)
       
    #################################################################
    # write information into a class-specific file for use when creating object
    with open ('./'+'attribute_library/'+'___'+ para_info['class_name'] + '___info___' + ".py",'w+') as f3:
        f3.write("addi_info = {" + para_info_val_in_str + "}")
        f3.close()
    # Define mapping between the generated network element and its parent network element
    
    content = para_info['parent_class'] +'___' + para_info['class_name'] + '=' + '"___' + para_info['class_name'] + '___"'
    
       
    with open ('./'+'attribute_library/'+"attribute_mapping.py",'a+') as f4:        
        cur_data = open('./'+'attribute_library/'+"attribute_mapping.py", 'r').read()  # for reading
        f4.close()
        
    if content not in cur_data:
        with open ('./'+'attribute_library/'+"attribute_mapping.py",'a+') as f5:
            f5.write(content + "\n")
            f5.close()

    
sleep_time = 1
'''
Link specific attributes
'''
print('--------------------------------------------------------------------------------------------------')
print('----------------------------------Adding Link Specifc Atrributes----------------------------------')
print('--------------------------------------------------------------------------------------------------')
# Adding Link Power
info = {'class_name':nng.lkpwr, 'parent_cls':nng.lk_prnt_cls, 'para_type':nng.leaf_para, 'layer':nng.phy, 'hid':nng.tsmt_nd}
para_info = add_attribute(info)
do_file_ops(para_info)
print('Link Power Attribute Added')
time.sleep(sleep_time)

# Adding Link Capacity
info = {'class_name':nng.lkcap, 'parent_cls':nng.lk_prnt_cls, 'para_type':nng.itmd_para, 'layer':nng.phy, 'hid':nng.tsmt_nd}
para_info = add_attribute(info)
do_file_ops(para_info)
print('Link Capacity Attribute Added')
time.sleep(sleep_time)

# Adding Link SINR
info = {'class_name':nng.lksinr, 'parent_cls':nng.lk_prnt_cls, 'para_type':nng.itmd_para, 'layer':nng.phy, 'hid':nng.tsmt_nd}
para_info = add_attribute(info)
do_file_ops(para_info)
print('Link SINR Attribute Added')
time.sleep(sleep_time)

# Adding Link Distance
info = {'class_name':nng.lkdist, 'parent_cls':nng.lk_prnt_cls, 'para_type':nng.itmd_para, 'layer':nng.phy, 'hid':nng.tsmt_nd}
para_info = add_attribute(info)
do_file_ops(para_info)
print('Link Distance Attribute Added')
time.sleep(sleep_time)

# Adding Link Gain
info = {'class_name':nng.lkgain, 'parent_cls':nng.lk_prnt_cls, 'para_type':nng.mesr_para, 'layer':nng.phy, 'hid':nng.tsmt_nd}
para_info = add_attribute(info)
do_file_ops(para_info)
print('Link Gain Attribute Added')
time.sleep(sleep_time)

# Adding Link Interference
info = {'class_name':nng.lkitf, 'parent_cls':nng.lk_prnt_cls, 'para_type':nng.xtnl_para, 'layer':nng.phy, 'hid':nng.tsmt_nd}
para_info = add_attribute(info)
do_file_ops(para_info)
print('Link Interference Attribute Added')
time.sleep(sleep_time)

# Adding Link Aggregate Rate
info = {'class_name':nng.lkinrate, 'parent_cls':nng.lk_prnt_cls, 'para_type':nng.itmd_para, 'layer':nng.tspt, 'hid':nng.tsmt_nd}
para_info = add_attribute(info)
do_file_ops(para_info)
print('Link Aggregate Rate Attribute Added')
time.sleep(sleep_time)

# Adding Link Delay 
info = {'class_name':nng.lkdelay, 'parent_cls':nng.lk_prnt_cls, 'para_type':nng.itmd_para, 'layer':nng.tspt, 'hid':nng.tsmt_nd}
para_info = add_attribute(info)
do_file_ops(para_info)
print('Link Delay Attribute Added')
time.sleep(sleep_time)
'''
Session specific attributes
'''
print('--------------------------------------------------------------------------------------------------')
print('---------------------------------Adding Session Specifc Atrributes--------------------------------')
print('--------------------------------------------------------------------------------------------------')

# Adding Session Rate
info = {'class_name':nng.ssrate, 'parent_cls':nng.ss_prnt_cls, 'para_type':nng.leaf_para, 'layer':nng.tspt, 'hid':nng.src}
para_info = add_attribute(info)
do_file_ops(para_info)
print('Session Rate Attribute Added')
time.sleep(sleep_time)

# Adding Session Delay
info = {'class_name':nng.ssdelay, 'parent_cls':nng.ss_prnt_cls, 'para_type':nng.itmd_para, 'layer':nng.tspt, 'hid':nng.src}
para_info = add_attribute(info)
do_file_ops(para_info)
print('Session Delay Attribute Added')
time.sleep(sleep_time)
'''
Node/link specific atrributes
'''
print('--------------------------------------------------------------------------------------------------')
print('--------------------------------Adding Node/link Specifc Atrributes-------------------------------')
print('--------------------------------------------------------------------------------------------------')
# Adding X Coordinate 
info = {'class_name':nng.coord_x, 'parent_cls':nng.lk_prnt_cls, 'para_type':nng.leaf_para, 'layer':nng.phy, 'hid':nng.tsmt_nd}
para_info = add_attribute(info)
do_file_ops(para_info)
print('X Coordinate Attribute Added')
time.sleep(sleep_time)

#Adding Y Coordinate 
info = {'class_name':nng.coord_y, 'parent_cls':nng.lk_prnt_cls, 'para_type':nng.leaf_para, 'layer':nng.phy, 'hid':nng.tsmt_nd}
para_info = add_attribute(info)
do_file_ops(para_info)
print('Y Coordinate Attribute Added')
time.sleep(sleep_time)

#Adding Z Coordinate 
info = {'class_name':nng.coord_z, 'parent_cls':nng.lk_prnt_cls, 'para_type':nng.leaf_para, 'layer':nng.phy, 'hid':nng.tsmt_nd}
para_info = add_attribute(info)
do_file_ops(para_info)
print('Z Coordinate Attribute Added')
time.sleep(sleep_time)

# Adding Fixed X Coordinate 
info = {'class_name':nng.fx_crd_x, 'parent_cls':nng.lk_prnt_cls, 'para_type':nng.xtnl_para, 'layer':nng.phy, 'hid':nng.tsmt_nd}
para_info = add_attribute(info)
do_file_ops(para_info)
print('Fixed X Coordinate Attribute Added')
time.sleep(sleep_time)

#Adding Fixed Y Coordinate 
info = {'class_name':nng.fx_crd_y, 'parent_cls':nng.lk_prnt_cls, 'para_type':nng.xtnl_para, 'layer':nng.phy, 'hid':nng.tsmt_nd}
para_info = add_attribute(info)
do_file_ops(para_info)
print('Fixed Y Coordinate Attribute Added')
time.sleep(sleep_time)

#Adding Fixed Z Coordinate 
info = {'class_name':nng.fx_crd_z, 'parent_cls':nng.lk_prnt_cls, 'para_type':nng.xtnl_para, 'layer':nng.phy, 'hid':nng.tsmt_nd}
para_info = add_attribute(info)
do_file_ops(para_info)
print('Fixed Z Coordinate Attribute Added')
time.sleep(sleep_time)




