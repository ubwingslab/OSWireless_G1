#######################################################
# Automatically Generated Solution Algorithm
#------------------------------------------------------
#[[[cog
#   import cog, datetime
#   cog.outl("# Code Date: %s" % datetime.datetime.now())
#]]]
#[[[end]]]
# Author: Sabarish Krishna Moorthy
#######################################################

#Insert the path of the algorithm
#[[[cog
#   import __alg_name
#   cog.outl("sys.path.insert(0, '%s')"%__alg_name.algo_name)
#]]]
#[[[end]]]

# Import Lagrangian coefficients and network parameters
#[[[cog
#   import cog, datetime
#   import __alg_name
#   cog.outl("from lag_in_%s import *"%__alg_name.hid)
#   cog.outl("from __net_para_%s import *"%__alg_name.hid)
#   cog.outl("from __q_learning_hyperparameters_%s import *"%__alg_name.hid)
#]]]
#[[[end]]]

import netcfg
import random
import net_name_g2

########################################################
#              Define Objective Function
########################################################
#[[[cog
#   import sys, importlib
#   import cog, __alg_name, __alg_utility, __alg_variable
#   cog.outl("def func(%s, sign=-1.0):"% 'objvar')
#   cog.outl("	utlt = %s"%(__alg_utility.value))
#   cog.outl("	pnl = - sum(%s*(%s - %s))"%(__alg_utility.pnl_sum, __alg_variable.value, __alg_utility.objvarkey))
#   cog.outl("	ovl_utlt = utlt + pnl")
#   cog.outl("	return ovl_utlt")
#]]]
#[[[end]]]


def q_rl_alg(actions, reward_val):

    # Reward Value
    #[[[cog
    #   import cog
    #   cog.outl("reward = func(%s)"%__alg_utility.lwr)
    #]]]
    #[[[end]]]
     
    rnd_val = random.uniform(0,1)
    old_q_val = netcfg.q_state_act_dict[netcfg.cur_state]
    dec_tuple = make_decision(rnd_val, actions)
    new_val = netcfg.q_state_act_dict[tuple(dec_tuple)]
    updt_q_val = old_q_val + alpha*((reward + gamma*new_val) - old_q_val)
    netcfg.q_state_act_dict.update({dec_tuple:updt_q_val})
    
    
    return dec_tuple
  
def make_decision(ep_val, actions):
    old_state = netcfg.val_id
    if ep_val < 1-netcfg.epsilon:
        print 'Taking arg max action'
        state_val, action_sel = get_arg_max_st_act(netcfg.val_id, actions)
        print state_val, action_sel
                                
    else:
        print 'Taking random action'
        action_sel = random.choice(actions)
        print rnd_act, 'is chosen'
        
    dec_tuple = (old_state, act)
          
    return dec_tuple

    
def get_arg_max_st_act(state_val, actions):
    
    all_values = []
    for acti in actions:
        tuple_act = (state_val, acti)
        val = netcfg.q_state_act_dict[tuple_act]
        all_values.append(val)
           
    get_arg_max_val = max(all_values)
    idx = all_values.index(max(all_values))
    action_sel = actions[idx]
    #arg_max_st_act = (state_val, action_sel)
    return state_val, action_sel
    
    
    
    
    
    
    
    
    

