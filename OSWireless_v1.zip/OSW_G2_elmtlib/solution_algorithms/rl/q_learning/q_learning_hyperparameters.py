# Initialize step size parameter
alpha = 0.1

# Discount factor
gamma = 1