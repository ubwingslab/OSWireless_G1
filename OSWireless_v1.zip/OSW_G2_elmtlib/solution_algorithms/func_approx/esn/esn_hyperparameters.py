import numpy as np
n_outputs=1
n_reservoir=80
spectral_radius=1
sparsity=0.02
noise=0.000001
teacher_scaling=1
teacher_shift=-0.4
out_activation=np.tanh
inverse_out_activation=np.arctanh
random_state=np.random.RandomState(42) 
silent=False
train_test_cutoff = 90