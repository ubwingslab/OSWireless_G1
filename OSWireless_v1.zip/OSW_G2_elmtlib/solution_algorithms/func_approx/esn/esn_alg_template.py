#######################################################
# Automatically Generated Solution Algorithm
#------------------------------------------------------
#[[[cog
#   import cog, datetime
#   cog.outl("# Code Date: %s" % datetime.datetime.now())
#]]]
#[[[end]]]
# Author: Sabarish Krishna Moorthy
#######################################################

from pyESN import ESN
import hyperparameters
import numpy as np

#Insert the path of the algorithm
#[[[cog
#   import __alg_name
#   cog.outl("sys.path.insert(0, '%s')"%__alg_name.algo_name)
#]]]
#[[[end]]]

# Import Lagrangian coefficients and network parameters
#[[[cog
#   import cog, datetime
#   import __alg_name
#   cog.outl("from __lag_in_%s import *"%__alg_name.hid)
#   cog.outl("from __net_para_%s import *"%__alg_name.hid)
#   cog.outl("from __esn_hyperparameters_%s import *"%__alg_name.hid)
#]]]
#[[[end]]]

def load_data_set(file_name):
    '''
    Load the data set to be used to train ESN
    '''
    with open(file_name, 'rb') as f:
        data = np.load(f)
        
    return data
    
def data_format(data):
    total_col_num = data.shape[1]
    reward_col = data[:, total_col_num-n_outputs]
    max_reward = max(reward_col)
    norm_max_reward = reward_col/max_reward/2
    norm_max_reward = np.transpose(norm_max_reward)
    data_input = data[:,0:total_col_num - n_outputs]
    
    return total_col_num-n_outputs, data_input, norm_max_reward
    
def esn(num_col, num_op):
    esn = ESN(n_inputs=num_col,
              n_outputs=num_op,
              n_reservoir=n_reservoir,
              spectral_radius=spectral_radius,
              sparsity=sparsity,
              noise=noise,
              input_shift = np.zeros(num_col),
              input_scaling = np.ones(num_col),
              teacher_scaling=teacher_scaling,
              teacher_shift=-teacher_shift,
              out_activation=out_activation,
              inverse_out_activation=inverse_out_activation,
              random_state=random_state,
              silent=silent) 
    return esn

def esn_train(file_name):
    data = load_data_set(file_name)
    formatted_data, data_input, data_reward = data_format(data)
    esn_obj = esn(np.shape(data_input)[1], n_outputs)
    ttc = int(np.ceil(traintest_cutoff*np.shape(data_input)[1]))
    train_data, train_data_reward = data_input[0:ttc], data_reward[0:ttc]
    test_data, test_data_reward = data_input[ttc:], data_reward[ttc:]
    pred_train = esn_obj.fit(train_data, train_data_reward)
    pred_test = esn_obj.predict(test_data)
    
    return esn_obj
    
    
