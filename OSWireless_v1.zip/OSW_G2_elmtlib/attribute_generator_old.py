'''
Author: Sabarish Krishna Moorthy, Zhangyu Guan
'''

#Attribute Generator
import sys, os, time, inspect
current_dir = os.path.dirname(os.path.abspath(inspect.getfile(inspect.currentframe())))
parent_dir = os.path.dirname(current_dir)
sys.path.insert(0, parent_dir+'\\OSW-G2\\NeXT-OS\\wos-network') 
import net_name_g2 as nng
#exit()
import subprocess

########################################################################
def dic_2_str(dict):
    '''
    convert a dictionary to a string
    '''
    # get the list of keys of the dictionary
    list_key = dict.keys()    
        
    # initialize the overall string to be empty 
    overall_str = ''       
    
    # add each key and its value to a string
    for this_key in list_key:
        # construc the current part of string
        cur_str = "'" + this_key + "': '" + dict[this_key] + "'," 
    
        # add current string to the overall string
        overall_str = overall_str + cur_str
        
    return overall_str[:-1]    # no need to return the last comma
########################################################################

# Information of the network parameter to be defined

# Added a class with specific attributes

def add_attribute(info):
    # for session parameters
    para_info = {}
    para_info['class_name'] = info['class_name']             #net_name.ssrate}      # name of the class to be generated
    para_info['parent_class'] = info['parent_cls']         #net_name.ss_prnt_cls  # parent class
    para_info['para_type'] = info['para_type']               #net_name.leaf_para    # is this parameter a leaf parameter?
    para_info['layer'] = info['layer']                       #net_name.tspt         # protocol layer of this parameter
    para_info['hid'] = info['hid']                           #net_name.src          # this parameter is controlled by source node
    #para_info['sub_type'] = info['stype']                 #net_name.rate         # general category of this parameter
    return para_info

def do_cogapp(para_info):
    out_file = './'+'attribute_library/'+'___' + para_info['class_name'] + '___' + '.py'  # this is output file name
    
    #################################################################
    # Generate the class file
    os.system('python -m cogapp -d -o ' + out_file + ' attribute_tmplt.py ')

    #################################################################
    # Generate callback file
    out_file = './'+'attribute_library/'+'___' + para_info['class_name'] + '__callback' + '.py'  # this is output file name
    os.system('python -m cogapp -d -o ' + out_file + ' attribute_callback_tmplt.py ')
    

def do_file_ops(para_info):
    # convert the dictionary to a string
    para_info_val_in_str = dic_2_str(para_info)

    #Function encapsulating all of the housekeeping file operations for the defined attribute
    #################################################################
    # write information into a file for temporary use
    with open ('./'+"attribute_tmplt_val.py",'w+') as f1:
        f1.write("addi_info = {" + para_info_val_in_str + "}")
        #print ("f1", para_info_val_in_str) #ok
        
    with open ('./'+"attribute_class_val.py",'w+') as f2:
        f2.write("class_name = \"___%s___\""%para_info['class_name'])

    do_cogapp(para_info)
    
    # close the files
    f1.close()
    f2.close()

    #################################################################
    # write information into a class-specific file for use when creating object
    with open ('./'+'attribute_library/'+'___'+ para_info['class_name'] + '___info___' + ".py",'w+') as f3:
        f3.write("addi_info = {" + para_info_val_in_str + "}")
        f3.close()
    # Define mapping between the generated network element and its parent network element
    
    content = para_info['parent_class'] +'___' + para_info['class_name'] + '=' + '"___' + para_info['class_name'] + '___"'
    
       
    with open ('./'+'attribute_library/'+"attribute_mapping.py",'a+') as f4:        
        cur_data = open('./'+'attribute_library/'+"attribute_mapping.py", 'r').read()  # for reading
        f4.close()
        
    if content not in cur_data:
        with open ('./'+'attribute_library/'+"attribute_mapping.py",'a+') as f5:
            f5.write(content + "\n")
            f5.close()

    

# Adding Session Rate
info = {'class_name':nng.ssrate, 'parent_cls':nng.ss_prnt_cls, 'para_type':nng.leaf_para, 'layer':nng.tspt, 'hid':nng.src}
para_info = add_attribute(info)
do_file_ops(para_info)
print('Session Rate Attribute Added')