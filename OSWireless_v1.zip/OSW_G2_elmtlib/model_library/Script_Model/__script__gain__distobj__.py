def __script__gain__distobj__(object_obj, obj_parameter):
    '''
    func: Generate the expression for gain
    object_obj: Atrribute parent object
    obj_parameter: Single dependent attribute, the argument type should be an object
    returns: Expression String
    '''

    variable_distance_attr = obj_parameter.stype
    expr = '('+variable_distance_attr+')**-4'

    return expr