def __lksinr__script__def__(object_obj, model_parameter):
    expr = '(lkpwr*lkgain)/lkitf'
    return expr