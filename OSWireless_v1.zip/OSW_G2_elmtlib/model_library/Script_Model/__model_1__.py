import net_name_g2

def __model_1__(object_obj, str_model_parameter):
    # '''
    # func: This function is used to obtain the parameter for the default ssdelay model
    # obj: This is the parent object of the session which will be used to obtain the set of dependent elements 
    # '''
    # #print(object_obj, object_obj.name, variable_view_elmt, list_dep_elmt, variable_elmt_attr)
    # #print(type(obj), type(view_elmt), type(dep_view_elmt), type(elmt_attr))
    # '''
    # For a given view element, get its dependent view elements
    # '''
    # #dep_set = getattr(object_obj, variable_dep_view_elmt)
    # #print('xxxx', dep_set)
    # '''
    # Loop over the dependent set to obtain the expression
    # '''
    
    attr_name = str_model_parameter[0]
    
    expr = ''

    list_dep_elmt = getattr(object_obj, object_obj.dependent_set)

    for dep_elmt in list_dep_elmt:
        expr_name = object_obj.ntwk.get_expr_g2(dep_elmt, attr_name)
        if expr == '':
            expr = expr_name['expr_xpd']
        else:
            expr = expr+'+'+expr_name['expr_xpd']

    return expr