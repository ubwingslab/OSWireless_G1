def __lksinr__micro__script__def__(object_obj, model_parameter):
    expr = '(lkpwr*lkgain)/lkitf'
    return expr