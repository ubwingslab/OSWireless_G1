def __script__gain__diststr__(object_obj, str_parameter):
    '''
    func: Generate the expression for gain
    object_obj: Atrribute parent object
    obj_parameter: Single dependent attribute, the argument type should be a string
    returns: Expression String
    '''

    variable_distance_attr = str_parameter[0]
    expr = '('+variable_distance_attr+')**-4'

    return expr