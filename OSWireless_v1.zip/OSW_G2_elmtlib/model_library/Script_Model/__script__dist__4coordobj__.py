def __script__dist__4coordobj__(object_obj, list_obj_parameter):
    '''
    func: Generate the expression for distance between two nodes based on X,Y coordinate system
    object_obj: Atrribute parent object
    str_list_parameter: List of dependent attributes, type of elements in the list is object
    returns: Expression String
    '''

    osobj_coordx1= list_obj_parameter[0]
    osobj_coordx2= list_obj_parameter[1]
    osobj_coordy1= list_obj_parameter[2]
    osobj_coordy2= list_obj_parameter[3]

    expr1 = '%s-%s'%(osobj_coordx1.name, osobj_coordx2.name)
    expr2 = '%s-%s'%(osobj_coordy1.name, osobj_coordy2.name)

    expr = '('+expr1+')'+'**2'+'+'+'('+expr2+')'+'**2'
    expr = '('+expr+')**(1/2)'

    return expr
           