def __script__mm1__(obj, list_str_parameter):
    osstr_service_rate = list_str_parameter[0]
    osstr_arrival_rate = list_str_parameter[1]
    expr = '1/('+osstr_service_rate+'-('+osstr_arrival_rate+'))'
    return expr
