import net_name_g2

def __lkinrate__script__def__(obj, a, b, c):
    '''
    func: Get the aggregate incoming rate for a link
    obj: object of the parameter (link object)
    '''
    '''
    For a given link, get its dependent sessions
    '''
    dependent_ses = obj.session_set

    '''
    Loop over the sessions to obtain the aggregate incoming rate 
    '''
    expr = ''
    for ses in dependent_ses:
        lkinrate = obj.ntwk.get_expr_g2(ses, net_name_g2.ssrate)
        if expr == '':
            expr = lkinrate['expr_xpd']
        else:
            expr = expr+'+'+lkinrate['expr_xpd']
        
    return expr