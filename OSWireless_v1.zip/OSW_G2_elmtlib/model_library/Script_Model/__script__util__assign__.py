import net_name_g2
def __script__util__assign__(obj, list_str_parameter):
    '''
    Function to create expressions based on element object and the list of string parameters 
    '''
    expr = ''
    if len(list_str_parameter) == 1:
        if obj.type == 'node':
            print(obj.name)
            agent_idx = obj.index
            for task_idx in range(len(obj.task_set)):
                task_name = obj.ntwk.task_list[task_idx]
                expr1 = obj.name + '_'+task_name
                expr = const_name(task_idx, expr, expr1)
                
                attr = getattr(obj.ntwk, obj.name)
                setattr(obj.ntwk, '_'+expr1, attr)
                expr_obj = getattr(obj.ntwk, '_'+expr1)
                setattr(expr_obj, 'parent', obj)
            expr='('+expr+')'    
        if obj.type == 'task':
            task_idx = obj.index
            for agent_idx in range(len(obj.node_set)):
                task_name = obj.name
                expr1 = task_name+'_'+obj.node_set[agent_idx]
                print(expr1)
                agent_obj = obj.ntwk.get_netelmt_g2(obj.node_set[agent_idx])
                attr = getattr(obj.ntwk, task_name)
                setattr(obj.ntwk, '_'+expr1, agent_obj)
                expr = const_name(agent_idx, expr, expr1)
                expr_obj = getattr(obj.ntwk, '_'+expr1)
                setattr(expr_obj, 'parent', agent_obj)
            expr='('+expr+')'
    elif len(list_str_parameter) == 2:
        agent_idx = obj.index
        for task_idx in range(len(obj.ntwk.task_list)):
            expr1 = list_str_parameter[0]+'_agent_'+str(agent_idx)+'_task_'+str(task_idx)+'*'+list_str_parameter[1]+'_agent_'+str(agent_idx)+'_task_'+str(task_idx)
            expr = const_name(task_idx, expr, expr1)
    else:
        print('Not Supported for now.')
    
    return expr
    
def const_name(idx, expr, expr1):
    '''
    Function to construct name by concatenation
    '''
    if idx ==0:
        expr = expr1
    else:
        expr=expr+'+'+expr1
        
    return expr
   
  
