def __script__dist__4coord__(object_obj, list_str_parameter):
    '''
    func: Generate the expression for distance between two nodes based on X,Y coordinate system
    object_obj: Atrribute parent object
    str_list_parameter: List of dependent attributes, type of elements in the list is string
    returns: Expression String
    '''
    osstr_coord1= list_str_parameter[0]
    osstr_coord2= list_str_parameter[1]
    osstr_coord3= list_str_parameter[2]
    osstr_coord4= list_str_parameter[3]
    
    expr1 = '%s-%s'%(osstr_coord1, osstr_coord2)
    expr2 = '%s-%s'%(osstr_coord3, osstr_coord4)

    expr = '('+expr1+')'+'**2'+'+'+'('+expr2+')'+'**2'
    expr = '('+expr+')**(1/2)'

    return expr
           