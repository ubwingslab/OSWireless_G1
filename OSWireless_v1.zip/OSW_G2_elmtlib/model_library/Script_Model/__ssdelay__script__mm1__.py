import net_name_g2, netcfg_g2

def __ssdelay__script__mm1__(obj):
    '''
    func: This function is used to obtain the parameter for the default ssdelay model
    elmt_obj: This is the parent object of the session which will be used to obtain the set of dependent elements 
    '''
    parent_obj = obj.parent
    elmt_set = parent_obj.link_set

    expr = script_gen_expr(obj, elmt_set)

    return expr
    
def script_gen_expr(obj, elmt_set):
    '''
    func: This function returns the expression for the given element set and the element parameter
    obj: This is the parent object
    elmt_set: list of all elements belonging to the elmnt object
    '''
    
    final_expr = ''
    for elmt in elmt_set:
        elmt_obj = obj.get_netelmt_g2(elmt)
        '''
        For each element get the aggregate link rate expressions and link capacity expression
        '''
        lkinrate_expr = obj.ntwk.get_expr_g2(elmt, net_name_g2.lkinrate)
        lkcap_expr = obj.ntwk.get_expr_g2(elmt, net_name_g2.lkcap)
        
        '''
        Format the obtained expression for easy expression generation
        '''
        lkinrate_expr_ori = lkinrate_expr['expr_ori'] 
        lkinrate_expr_expd = lkinrate_expr['expr_xpd'] 
        lkcap_expr_ori = lkcap_expr['expr_ori'] 
        lkcap_expr_expd = lkcap_expr['expr_xpd'] 

        '''
        Name of the auxiliary variable model used to get the intermediate variable name
        '''
        aux_var_model = 'mm1'
        itmd_var_name = net_name_g2.itmd_vars[aux_var_model]
        
        '''
        Prepare the new intermediate variable name based on the name of the element object
        '''
        aux_var = itmd_var_name+'_'+elmt
        itmd_expr = '1'+'/'+aux_var
        ori_expr = lkcap_expr_ori +'-'+ '('+lkinrate_expr_expd+')' 
        expd_expr = lkcap_expr_expd +'-'+ '('+lkinrate_expr_expd+')'

        '''
        Store the expression in the element object, it will be later used to record the expressions
        '''
        elmt_obj.aux_vars = ({aux_var_model:(aux_var, ori_expr, expd_expr)})

        if final_expr == '':
            final_expr = itmd_expr
        else:
            final_expr = final_expr+'+'+itmd_expr

    return final_expr