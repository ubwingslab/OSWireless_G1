import net_name_g2
def __script__util__assign2__(obj, list_str_parameter):
    '''
    Function to create expressions based on element object and the list of string parameters 
    '''
    expr = ''
    if len(list_str_parameter) == 1:
        if obj.type == 'node':
            agent_idx = obj.index
            expr = obj.name
            for task_idx in range(len(obj.ntwk.task_list)):
                expr1 = list_str_parameter[0]+'_'+str(agent_idx)+'_'+str(task_idx)
                expr = const_name(task_idx, expr, expr1)
            expr = '('+expr+')'
        if obj.type == 'task':
            task_idx = obj.index
            for agent_idx in range(len(obj.ntwk.node_list)):
                expr1 = list_str_parameter[0]+'_'+str(agent_idx)+'_'+str(task_idx)
                expr = const_name(agent_idx, expr, expr1)
            expr = '('+expr+')'        
    elif len(list_str_parameter) == 2:
        agent_idx = obj.index
        expr = ''
        reward_expr = obj.ntwk.get_expr_g2(obj.name, net_name_g2.reward)['expr_xpd']
        assign_expr = obj.ntwk.get_expr_g2(obj.name, net_name_g2.assign)['expr_xpd']
        reward_assign_expr = reward_expr+'*'+'('+assign_expr+')'
        expr = reward_assign_expr
    else:
        print('Not Supported for now.')

    return expr
    
def const_name(idx, expr, expr1):
    '''
    Function to construct name by concatenation
    '''
    if idx ==0:
        expr = expr1
    else:
        expr=expr+'+'+expr1
        
    return expr
   
  
