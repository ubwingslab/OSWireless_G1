import net_name_g2, netcfg_g2

def __lkdist__script__def__(obj):
    # Get the parent object based on the elmt object
    parent_obj = obj.parent
    
    # Generate the epxression
    para_expr = scrip_gen_expr(parent_obj)
    return para_expr

    
def scrip_gen_expr(obj):
    '''
    Generate the link distance expression for the given node pair
    ep is elmt_para 
    ndp is ndpair
    '''
    pex = '' #para_expr
    
    # Loop over X, Y, Z coordinate to generate the expression for the lk distance
    for crd in net_name_g2.coord_list:
        
        expr1 = obj.ntwk.gen_expr_g2(obj.name, net_name_g2.coord_list[crd], True)
        expr2 = obj.ntwk.gen_expr_g2(obj.name, net_name_g2.coord_list2[crd], True)

        expr = expr1+'-'+expr2
        # If the parameter expression is empty, assign the generated expr to the para expr
        # else, concatenate the existing para expr and the new expr
        if pex == '':
            pex='('+expr+')'+'**2'
        else:
            pex=pex+'+'+'('+expr+')'+'**2'

    return pex