import net_name_g2
def __script__assign__(obj, list_str_parameter):
    expr = '1'
    return expr
   
  
