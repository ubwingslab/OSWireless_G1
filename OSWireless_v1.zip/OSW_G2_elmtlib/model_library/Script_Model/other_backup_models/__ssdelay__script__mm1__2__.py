import net_name_g2

def __ssdelay__script__mm1__2__(obj, a, b, c):
    '''
    func: This function is used to obtain the parameter for the default ssdelay model
    obj: This is the parent object of the session which will be used to obtain the set of dependent elements 
    '''
    '''
    For a given session, get its dependent links
    '''
    link_set = obj.link_set
    
    '''
    Loop over the links to obtain the total session delay
    '''
    expr = ''
    for lk in link_set:
        expr_name = obj.ntwk.get_expr_g2(lk, net_name_g2.lkdelay)
        if expr == '':
            expr = expr_name['expr_xpd']
        else:
            expr = expr+'+'+expr_name['expr_xpd']
    return expr