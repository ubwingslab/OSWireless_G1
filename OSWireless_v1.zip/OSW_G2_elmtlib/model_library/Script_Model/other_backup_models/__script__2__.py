def __script__2__(object_obj, list_parameter):

    variable_distance_attr = list_parameter[0]
    expr = '('+variable_distance_attr+')**-4'

    return expr