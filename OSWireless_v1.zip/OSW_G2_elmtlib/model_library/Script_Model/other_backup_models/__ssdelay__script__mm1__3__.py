import net_name_g2

def __ssdelay__script__mm1__3__(obj, dummy):
    '''
    func: This function is used to obtain the parameter for the default ssdelay model
    obj: This is the parent object of the session which will be used to obtain the set of dependent elements 
    '''
    parent_obj = obj.parent
    
    '''
    For a given session, get its dependent links
    '''
    link_set = parent_obj.link_set

    expr = obj.parent.delay_expr['expr_xpd']

    return expr