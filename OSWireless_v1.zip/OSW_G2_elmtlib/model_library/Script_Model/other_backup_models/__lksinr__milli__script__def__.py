def __lksinr__milli__script__def__(object_obj, model_parameter):
    expr = '(lkpwr*lkgain)/lkitf'
    return expr