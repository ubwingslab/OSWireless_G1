import net_name_g2
def __script__util__(obj, list_str_parameter):

    agent_idx = obj.index
    expr = ''
    for task_idx in range(len(obj.ntwk.task_list)):
        expr1 = 'reward_'+str(agent_idx)+'_'+str(task_idx)+'*assign_'+str(agent_idx)+'_'+str(task_idx)
        if task_idx ==0:
            expr = expr1
        else:
            expr=expr+'+'+expr1

    return expr
   
  
