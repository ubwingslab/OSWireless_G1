print('OSWireless G2 Element Generator')

import sys, os, inspect, subprocess

def elmt_class_gen(elmnt):
    '''
    func: Generate class for the specific network element
    elmt: Name of the network element for which the class has to be generated
    '''
    with open ("elmt_tmplt_val.py",'w+') as f1:
        f1.write("class_name = \"%s\""%elmnt)
    f1.close()
    
    '''
    Prepare the name of the output file based on the name of the element 
    '''
    
    out_file = directory1+elmnt+'.py'  

    template_file = 'elmt_class_template.py'

    '''
    Generate the class file
    '''
    os.system('python -m cogapp -d -o ' + ' ' + out_file + ' ' +template_file)

'''
Name of the directory to store the generated element class
'''
directory1 = './'+'element_library'+'/'

'''
Get the list of arguments from the command line 
'''
print('Argument List:', sys.argv[1:])

'''
The first argument is the python file name, omitting it we will get the list of network elements to be added
'''
elmt_list = sys.argv[1:]

'''lllllllllllllllllllllllll
For each network element, prepare the corresponding class
'''
for elmnt in elmt_list:
    '''
    First store the name of the element in a temporary file. 
    '''
    print('Creating', elmnt, 'class')
    '''
    Call the element class generator to generate network element class
    '''
    elmt_class_gen(elmnt) 


