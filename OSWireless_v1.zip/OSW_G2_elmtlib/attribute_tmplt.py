#######################################################
#[[[cog
#   import cog, datetime
#   cog.outl("# Code Date: %s" % datetime.datetime.now())
#]]]
#[[[end]]]

# Author: Zhangyu Guan, Sabarish Krishna Moorthy
#[[[cog
#   import cog
#   import attribute_class_val as acv
#   cog.outl("# Automatically generated %s class" %(acv.class_name))
#]]]
#[[[end]]]
#######################################################

#[[[cog
#   import cog
#   import attribute_class_val as acv
#   cog.outl("import net_func_g2\n")
#   cog.outl("class %s(net_func_g2.netelmt_g2):" %(acv.class_name))
#   cog.outl("    '''")
#   cog.outl("    %s Class" %(acv.class_name))
#   cog.outl("    '''")
#]]]
#[[[end]]]
    '''
    class of network parameters and variables
    '''
    def __init__(self, info):    
        # from base network element
        net_func_g2.netelmt_g2.__init__(self, info) 

        # properties of parameter
        self.expr_hldr  =  None        # Symbolic expression of the element; There should be an expression management module
        self.expr_hldr_xtnl = None                          # external expression
                
        # protocol code: the code will be used to identify which function should be called to express a variable
        self.ptcl_code  = None

        # Lower and upper bounds of the parameter. APIs should be provided to set these bounds, hard coded for now.
        self.lwr_bnd = 'default'
        self.upr_bnd = 'default'   

        # if callback has been executed?
        self.callback_executed = False
    
        # self.para_type  =  info['addi_info']['para_type']   # parameter type
        
        for elmt in info['addi_info'].keys():
            if not hasattr(self, elmt):
                setattr(self, elmt, info['addi_info'][elmt])        
        